DROP DATABASE IF EXISTS `dedb`;
CREATE DATABASE IF NOT EXISTS `dedb`;
USE `dedb`;

DROP TABLE IF EXISTS `category`;
CREATE TABLE IF NOT EXISTS `category` (
  `category_id` int(11) NOT NULL,
  `name` varchar(55) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

truncate table `category`;
INSERT INTO `category` (`category_id`, `name`) VALUES
	(1, 'testCategory1'),
	(2, 'testCategory2');

DROP TABLE IF EXISTS `client`;
CREATE TABLE IF NOT EXISTS `client` (
  `client_id` int(11) NOT NULL,
  `name` varchar(55) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `email` varchar(55) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`client_id`),
  KEY `country_id` (`country_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

truncate table `client`;
INSERT INTO `client` (`client_id`, `name`, `address`, `email`, `country_id`) VALUES
	(0, 'n1', 'a1', 'abc@gmail.com', 1),
	(34668567, 'n2', 'a2', 'abc@gmail.com', 2);

DROP TABLE IF EXISTS `country`;
CREATE TABLE IF NOT EXISTS `country` (
  `country_id` int(11) NOT NULL,
  `name` varchar(55) DEFAULT NULL,
  PRIMARY KEY (`country_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

truncate table `country`;
INSERT INTO `country` (`country_id`, `name`) VALUES
	(1, 'testCountry1'),
	(2, 'testCountry2');

DROP TABLE IF EXISTS `product`;
CREATE TABLE IF NOT EXISTS `product` (
  `product_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`product_id`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

truncate table `product`;
INSERT INTO `product` (`product_id`, `name`, `price`, `stock`, `category_id`) VALUES
	(92210256, 'n1', 1, 0, 1);

DROP TABLE IF EXISTS `product_order`;
CREATE TABLE IF NOT EXISTS `product_order` (
  `product_order_id` int(11) NOT NULL,
  `client_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`product_order_id`),
  KEY `product_ID` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

truncate table `product_order`;
INSERT INTO `product_order` (`product_order_id`, `client_id`, `product_id`, `quantity`) VALUES
	(51274844, 0, 92210256, 1),
	(85967068, 0, 92210256, 1);
	
DROP TABLE IF EXISTS `user`;	
CREATE TABLE `user` (
	`id` INT(11) NOT NULL,
	`username` VARCHAR(55) NULL DEFAULT NULL,
	`password` VARCHAR(55) NULL DEFAULT NULL,
	PRIMARY KEY (`id`)
)
ENGINE=InnoDB
;
