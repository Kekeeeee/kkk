package com.de.view;


import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;

public class OrderPageView {

    private JPanel contentPane;
    private JTable clientTable;
    private JTable productTabel;
    private JTextField textField;
    private JCheckBox billCheckBox;
    private JButton createBtn;
    private JButton viewBtn;

    /**
     * Create the frame.
     */
    public OrderPageView() {
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null);

        textField = new JTextField();
        textField.setBounds(298, 60, 78, 22);
        contentPane.add(textField);
        textField.setColumns(10);

        JLabel quantityLabel = new JLabel("Quantity");
        quantityLabel.setBounds(310, 37, 56, 16);
        contentPane.add(quantityLabel);

        billCheckBox = new JCheckBox("Create a text bill");
        billCheckBox.setBounds(272, 91, 127, 25);
        contentPane.add(billCheckBox);

        createBtn = new JButton("Create order");
        createBtn.setBounds(276, 125, 123, 25);
        contentPane.add(createBtn);

        viewBtn = new JButton("View orders");
        viewBtn.setBounds(276, 269, 123, 25);
        contentPane.add(viewBtn);
    }

    public final void setClientTable(JTable newTable) {
        JLabel clientLabel = new JLabel("Clients");
        clientLabel.setBounds(12, 13, 56, 16);
        contentPane.add(clientLabel);

        clientTable = newTable;
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(12, 37, 240, 260);
        contentPane.add(scrollPane);
        clientTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        scrollPane.setViewportView(clientTable);
    }

    public final void setProductTabel(JTable newTable) {
        JLabel productLabel = new JLabel("Products");
        productLabel.setBounds(580, 13, 56, 16);
        contentPane.add(productLabel);

        productTabel = newTable;
        JScrollPane scrollPane_1 = new JScrollPane();
        scrollPane_1.setBounds(400, 37, 240, 260);
        contentPane.add(scrollPane_1);
        productTabel.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        scrollPane_1.setViewportView(productTabel);
    }

    public void showMessage(String msg) {
        JOptionPane.showMessageDialog(contentPane, msg);
    }

    public void showOrders(JTable table) {
        ShowData sD = new ShowData(table);
        sD.setVisible(true);
    }

    public void addInsertActionListener(ActionListener aL) {
        createBtn.addActionListener(aL);
    }

    public void addShowActionListener(ActionListener aL) {
        viewBtn.addActionListener(aL);
    }

    public JPanel getContentPane() {
        return contentPane;
    }

    public final JTable getClientTable() {
        return clientTable;
    }

    public final JTable getProductTabel() {
        return productTabel;
    }

    public final JCheckBox getBillCheckBox() {
        return billCheckBox;
    }

    public final JTextField getTextField() {
        return textField;
    }
}
