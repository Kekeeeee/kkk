package com.de.view;

import java.awt.Color;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import com.de.service.RegistService;
import com.de.service.impl.RegistServiceImpl;

public class RegistView extends JDialog {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private RegistService regisService = new RegistServiceImpl();
    private JTextField text_userName;
    private JPasswordField text_password;
    private JPasswordField text_repeat;
    private JLabel prompt;
    private final int WINDOWWIDTH = 296;
    private final int WINDOWHEIGH = 300;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        try {
        	RegistView dialog = new RegistView();
            dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
            dialog.setVisible(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Create the dialog.
     */
    public RegistView() {
        getContentPane().setForeground(Color.RED);
        setTitle("user regist");
        setAlwaysOnTop(true);
        getContentPane().setLayout(null);
        
        JLabel label = new JLabel("*username");
        label.setBounds(36, 42, 77, 18);
        getContentPane().add(label);
        
        JLabel label_1 = new JLabel("*password");
        label_1.setBounds(36, 80, 77, 15);
        getContentPane().add(label_1);
        
        text_userName = new JTextField();
        text_userName.setBounds(123, 42, 113, 21);
        getContentPane().add(text_userName);
        text_userName.setColumns(10);
        
        text_password = new JPasswordField();
        text_password.setEchoChar('*');
        text_password.setColumns(10);
        text_password.setBounds(123, 77, 113, 21);
        getContentPane().add(text_password);
        
        JLabel label_2 = new JLabel("*repeat password");
        label_2.setBounds(36, 122, 77, 15);
        getContentPane().add(label_2);
        
        text_repeat = new JPasswordField();
        text_repeat.setEchoChar('*');
        text_repeat.setColumns(10);
        text_repeat.setBounds(123, 119, 113, 21);
        getContentPane().add(text_repeat);
        
        JButton button = new JButton("");
        button.setText("regist");
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addUserAction(e);
            }
        });
        button.setBounds(36, 185, 77, 33);
        getContentPane().add(button);
        
        JButton button_1 = new JButton("");
        button_1.setText("reset");
        button_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                text_password.setText("");
                text_repeat.setText("");
                text_userName.setText("");
                prompt.setText("");
            }
        });
        button_1.setBounds(165, 185, 71, 33);
        getContentPane().add(button_1);
        
        prompt = new JLabel("");
        prompt.setForeground(Color.RED);
        prompt.setHorizontalAlignment(SwingConstants.CENTER);
        prompt.setBounds(36, 160, 200, 15);
        getContentPane().add(prompt);
        
        int width = Toolkit.getDefaultToolkit().getScreenSize().width;
        int heigh = Toolkit.getDefaultToolkit().getScreenSize().height;
        int x = (width-WINDOWWIDTH)/2;
        int y = (heigh-WINDOWHEIGH)/2;
        this.setBounds(x, y, 286, 278);
    }

    protected void addUserAction(ActionEvent e) {
        // TODO Auto-generated method stub
        String userName = text_userName.getText();
        char []pass = text_password.getPassword();
        String password = String.valueOf(pass);
        char []rep = text_repeat.getPassword();
        String repeat = String.valueOf(rep);
        if(userName.length() < 6) {
            prompt.setText("username length is error");
            return ;
        }else if( !password.equals(repeat) || (password.length() < 6 || password.length() > 20)){
            prompt.setText("password rule is error");
            return ;
        }
        try {
            boolean hasUser= regisService.hasUser(userName);
            if( hasUser == false) {
            	regisService.regist(userName, password);
                prompt.setText("regist success");
            }else {
                prompt.setText("username is exsists");
            }
        } catch (Exception e1) {
            e1.printStackTrace();
        }
    }
}
