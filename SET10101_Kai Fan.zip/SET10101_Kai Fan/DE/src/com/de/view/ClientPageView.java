package com.de.view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class ClientPageView {

    private JPanel contentPane;
	private JTable table;
	private JTextField nameTextField;
	private JTextField addressTestField;
	private JTextField emailTextField;
	private JTextField countryTextField;
	private JButton deleteBtn;
	private JButton refreshBtn;
	private JComboBox comboBox;
	private JButton addBtn;
	private JButton updateBtn;

	public ClientPageView() {
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Clients");
		lblNewLabel.setBounds(10, 13, 56, 16);
		contentPane.add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel.setBounds(334, 13, 286, 265);
		contentPane.add(panel);
		panel.setLayout(null);

		// JLabel
        JLabel idLabel = new JLabel("Id");
        idLabel.setBounds(12, 20, 56, 16);
        panel.add(idLabel);

		JLabel nameLabel = new JLabel("Name");
		nameLabel.setBounds(12, 84, 56, 16);
		panel.add(nameLabel);
		
		JLabel countryLabel = new JLabel("Country");
		countryLabel.setBounds(152, 148, 56, 16);
		panel.add(countryLabel);
		
		comboBox = new JComboBox();
		comboBox.setBounds(152, 177, 116, 22);
		panel.add(comboBox);

		JLabel addressLabel = new JLabel("Address");
		addressLabel.setBounds(152, 84, 56, 16);
		panel.add(addressLabel);
		
		JLabel emailLabel = new JLabel("E-mail");
		emailLabel.setBounds(12, 148, 56, 16);
		panel.add(emailLabel);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(12, 212, 256, 2);
		panel.add(separator);

		// JTextField
        nameTextField = new JTextField();
        nameTextField.setBounds(12, 113, 116, 22);
        panel.add(nameTextField);
        nameTextField.setColumns(10);

        addressTestField = new JTextField();
        addressTestField.setBounds(152, 113, 116, 22);
        panel.add(addressTestField);
        addressTestField.setColumns(10);

        emailTextField = new JTextField();
        emailTextField.setBounds(12, 177, 116, 22);
        panel.add(emailTextField);
        emailTextField.setColumns(10);

		countryTextField = new JTextField();
		countryTextField.setEditable(false);
		countryTextField.setBounds(12, 49, 56, 22);
		panel.add(countryTextField);
		countryTextField.setColumns(10);

		// Button
        addBtn = new JButton("Add");
        addBtn.setBounds(12, 227, 116, 25);
        panel.add(addBtn);

        updateBtn = new JButton("Update");
        updateBtn.setBounds(152, 227, 116, 25);
        panel.add(updateBtn);

		refreshBtn = new JButton("Refresh");
		refreshBtn.setBounds(161, 253, 119, 25);
		contentPane.add(refreshBtn);

        deleteBtn = new JButton("Delete selected");
        deleteBtn.setBounds(12, 253, 119, 25);
        contentPane.add(deleteBtn);

	}

	public void setTable(JTable newTable) {
        table = newTable;

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(12, 33, 268, 207);
        contentPane.add(scrollPane);
        scrollPane.setViewportView(table);

        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent evt) {
                int row = table.rowAtPoint(evt.getPoint());
                if (row >= 0) {
                    countryTextField.setText(table.getValueAt(row, 0).toString());
                    nameTextField.setText((String) table.getValueAt(row, 1));
                    addressTestField.setText((String) table.getValueAt(row, 2));
                    emailTextField.setText((String) table.getValueAt(row, 3));
                    comboBox.setSelectedIndex((Integer) table.getValueAt(row, 4) - 1);
                }
            }
        });
    }

    public int getIdOfSelected(){
        return (Integer)table.getValueAt(table.getSelectedRow(),0);
    }

    public void showMessage(String msg){
        JOptionPane.showMessageDialog(contentPane, msg);
    }

    public void addDeleteActionListener(ActionListener aL){
        deleteBtn.addActionListener(aL);
    }

	public void addSearchActionListener(ActionListener aL){
		refreshBtn.addActionListener(aL);
	}
	
	public void addInsertActionListener(ActionListener aL){
		addBtn.addActionListener(aL);
	}
	
	public void addUpdateActionListener(ActionListener aL){
		updateBtn.addActionListener(aL);
	}

	public final JTextField getNameTextField() {
		return nameTextField;
	}

    public JPanel getContentPane() {
        return contentPane;
    }

    public final JTextField getCountryTextField() {
        return countryTextField;
    }

    public final JComboBox getComboBox() {
        return comboBox;
    }

    public final JTextField getEmailTextField() {
        return emailTextField;
    }

    public final JTextField getAddressTestField() {
        return addressTestField;
    }
}
