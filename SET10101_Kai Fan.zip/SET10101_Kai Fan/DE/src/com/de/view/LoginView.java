package com.de.view;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import com.de.app.ApplicationMain;
import com.de.pojo.User;
import com.de.service.LoginService;
import com.de.service.impl.LoginServiceImpl;

public class LoginView extends JFrame {
	/**
     * 用户登陆界面。
     */
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JPasswordField text_password;
    private JButton bt_login;
    private JLabel l_Prompt;
    private Connection con;
    private LoginService loginService = new LoginServiceImpl();
    private JLabel label_2;
    private JTextField text_username;
    private final int WINDOWWIDTH = 386;
    private final int WINDOWHEIGH = 256;

    /**
     * Create the frame.
     */
    public LoginView() {
        setTitle("Welcome login");
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        contentPane = new JPanel();
        contentPane.setLayout(null);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        
        JLabel label = new JLabel("username");
        label.setFont(new Font("黑体", Font.PLAIN, 12));
        label.setBounds(60, 66, 68, 27);
        contentPane.add(label);
        
        JLabel label_1 = new JLabel("password");
        label_1.setFont(new Font("黑体", Font.PLAIN, 12));
        label_1.setBounds(60, 103, 68, 27);
        contentPane.add(label_1);
        
        text_password = new JPasswordField();
        text_password.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent e) {
                mouseExitedAction(e);
            }
            @Override
            public void mouseEntered(MouseEvent e) {
                mouseEnteredAction(e);
            }
        });
        text_password.setBounds(138, 106, 124, 21);
        contentPane.add(text_password);
        
        bt_login = new JButton("login");
        bt_login.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                loginAction(e);
            }
        });
        bt_login.setBounds(138, 160, 91, 40);
        contentPane.add(bt_login);
        
        l_Prompt = new JLabel("");
        l_Prompt.setForeground(Color.RED);
        l_Prompt.setFont(new Font("黑体", Font.PLAIN, 13));
        l_Prompt.setHorizontalAlignment(SwingConstants.CENTER);
        l_Prompt.setBounds(10, 29, 360, 27);
        contentPane.add(l_Prompt);
        
        label_2 = new JLabel("regist");
        label_2.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                new RegistView().setVisible(true);;
            }
            @Override
            public void mouseEntered(MouseEvent e) {
                new RegistView();
            }
        });
        label_2.setForeground(Color.BLUE);
        label_2.setBounds(284, 66, 53, 27);
        contentPane.add(label_2);
        
        text_username = new JTextField();
        text_username.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                mouseEnteredAction(e);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                mouseExitedAction(e);
            }
        });
        text_username.setBounds(138, 69, 124, 21);
        contentPane.add(text_username);
        text_username.setBorder(new LineBorder(new Color(0,0,0),1,false));
        text_password.setBorder(new LineBorder(new Color(0,0,0),1,false));
        text_username.setColumns(10);
        
        int width = Toolkit.getDefaultToolkit().getScreenSize().width;
        int heigh = Toolkit.getDefaultToolkit().getScreenSize().height;
        int x = (width-WINDOWWIDTH)/2;
        int y = (heigh-WINDOWHEIGH)/2;
        this.setBounds(x, y, WINDOWWIDTH, WINDOWHEIGH);
    }
    //鼠标进入编辑框事件
    private void mouseExitedAction(MouseEvent e) {
        // TODO Auto-generated method stub
        JTextField text =  (JTextField)e.getSource();
        text.setBorder(new LineBorder(new Color(0,0,0),1,false));
    }
    //鼠标退出编辑框事件
    private void mouseEnteredAction(MouseEvent e) {
        // TODO Auto-generated method stub
        JTextField text =  (JTextField)e.getSource();
        text.setBorder(new LineBorder(new Color(0,0,255),1,false));
    }

    private void loginAction(ActionEvent e) {
        User user = new User();
        String userName = text_username.getText();
        char[] pass = text_password.getPassword();
        String password = String.valueOf(pass);
        if(userName == null || userName.equals("")) {
            l_Prompt.setText("username can not null");
            return ;
        }else if(password == null || password.equals("")){
            l_Prompt.setText("password can not null");
            return ;
        }
        user.setUsername(userName);
        user.setPassword(password);
        try {
            String loginStr = loginService.login(userName, password);
            if(null != loginStr && "login success".equals(loginStr)) {
                l_Prompt.setText("Welcome, login success!");
                ApplicationMain mainPage = new ApplicationMain();
                mainPage.setVisible(true);
                LoginView frame = new LoginView();
                frame.setVisible(false);
            }else {
                l_Prompt.setText("username or password error.");
            }
        } catch (Exception e1) {
        	
        }     
    }
}
