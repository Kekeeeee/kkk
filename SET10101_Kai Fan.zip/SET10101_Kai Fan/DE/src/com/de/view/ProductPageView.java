package com.de.view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class ProductPageView {

    private JPanel contentPane;
	private JTable productTable;
	private JTextField nameTextField;
	private JTextField priceTextField;
	private JTextField stockTextField;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JTextField lowPriceTextLabel;
	private JTextField idTextField;
	private JButton deleteBtn;
	private JButton refreshBtn;
	private JButton addBtn;
	private JButton updateBtn;
	private JRadioButton allProductRadioBtn;
	private JRadioButton underStockRadioBtn;
	private JRadioButton lowerPriceRadioBtn;
	private JComboBox comboBox;

	/**
	 * Create the frame.
	 */
	public ProductPageView() {

		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		
		JLabel productLabel = new JLabel("Products");
		productLabel.setBounds(12, 13, 56, 16);
		contentPane.add(productLabel);
		
		deleteBtn = new JButton("Delete selected");
		deleteBtn.setBounds(12, 398, 119, 25);
		contentPane.add(deleteBtn);

		refreshBtn = new JButton("Refresh");
		refreshBtn.setBounds(161, 398, 119, 25);
		contentPane.add(refreshBtn);

		// ----product input JPanel start-----------------
		JPanel productInputJPanel = new JPanel();
		productInputJPanel.setBorder(new LineBorder(new Color(0, 0, 0)));
		productInputJPanel.setLayout(null);
		productInputJPanel.setBounds(320, 24, 320, 200);
		contentPane.add(productInputJPanel);

        JLabel idLabel = new JLabel("Id");
        idLabel.setBounds(12, 13, 56, 16);
        productInputJPanel.add(idLabel);

        idTextField = new JTextField();
        idTextField.setEditable(false);
        idTextField.setBounds(12, 37, 41, 22);
        productInputJPanel.add(idTextField);
        idTextField.setColumns(10);

        JLabel label = new JLabel("Name");
        label.setBounds(12, 72, 56, 16);
        productInputJPanel.add(label);

		nameTextField = new JTextField();
		nameTextField.setColumns(10);
		nameTextField.setBounds(12, 101, 153, 22);
		productInputJPanel.add(nameTextField);
		
		JLabel lblCategory = new JLabel("Category");
		lblCategory.setBounds(12, 136, 56, 16);
		productInputJPanel.add(lblCategory);
		
		comboBox = new JComboBox();
		comboBox.setBounds(12, 165, 153, 22);
		productInputJPanel.add(comboBox);

        JLabel priceLabel = new JLabel("Price");
        priceLabel.setBounds(177, 40, 56, 16);
        productInputJPanel.add(priceLabel);

		priceTextField = new JTextField();
		priceTextField.setColumns(10);
		priceTextField.setBounds(177, 69, 41, 22);
		productInputJPanel.add(priceTextField);
		
		stockTextField = new JTextField();
		stockTextField.setColumns(10);
		stockTextField.setBounds(252, 69, 41, 22);
		productInputJPanel.add(stockTextField);

        JLabel stockLabel = new JLabel("Stock");
        stockLabel.setBounds(252, 40, 56, 16);
        productInputJPanel.add(stockLabel);

        // button
        addBtn = new JButton("Add");
        addBtn.setBounds(177, 121, 116, 25);
        productInputJPanel.add(addBtn);

        updateBtn = new JButton("Update");
        updateBtn.setBounds(177, 164, 116, 25);
        productInputJPanel.add(updateBtn);
        // ----product input JPanel end-----------------


        JLabel filterLabel = new JLabel("Filters");
        filterLabel.setBounds(320, 253, 56, 16);
        contentPane.add(filterLabel);

        // ----filter select JPanel start-----------------
        JPanel filterJPanel = new JPanel();
		filterJPanel.setBorder(new LineBorder(new Color(0, 0, 0)));
		filterJPanel.setBounds(320, 281, 320, 142);
		contentPane.add(filterJPanel);
		filterJPanel.setLayout(null);
		
		JLabel showSelectLabel = new JLabel("Show:");
		showSelectLabel.setBounds(12, 9, 49, 16);
		filterJPanel.add(showSelectLabel);
		
		allProductRadioBtn = new JRadioButton("All products");
		allProductRadioBtn.setSelected(true);
		buttonGroup.add(allProductRadioBtn);
		allProductRadioBtn.setBounds(26, 34, 127, 25);
		filterJPanel.add(allProductRadioBtn);
		
		underStockRadioBtn = new JRadioButton("Understock products");
		buttonGroup.add(underStockRadioBtn);
		underStockRadioBtn.setBounds(26, 64, 145, 25);
		filterJPanel.add(underStockRadioBtn);
		
		lowerPriceRadioBtn = new JRadioButton("Products with prices smaller than");
		buttonGroup.add(lowerPriceRadioBtn);
		lowerPriceRadioBtn.setBounds(26, 94, 219, 25);
		filterJPanel.add(lowerPriceRadioBtn);
		
		lowPriceTextLabel = new JTextField();
		lowPriceTextLabel.setBounds(246, 95, 28, 22);
		filterJPanel.add(lowPriceTextLabel);
		lowPriceTextLabel.setColumns(10);
        // ----filter select JPanel end-----------------
    }

	public int getIdOfSelected(){
		return (Integer) productTable.getValueAt(productTable.getSelectedRow(),0);
	}

	public void showMessage(String msg){
		JOptionPane.showMessageDialog(contentPane, msg);
	}
	
	public void addDeleteActionListener(ActionListener al){
		deleteBtn.addActionListener(al);
	}
	
	public void addSearchActionListener(ActionListener aL){
		refreshBtn.addActionListener(aL);
	}
	
	public void addInsertActionListener(ActionListener aL){
		addBtn.addActionListener(aL);
	}
	
	public void addUpdateActionListener(ActionListener aL){
		updateBtn.addActionListener(aL);
	}
	
	public void setProductTable(JTable newTable){
		productTable = newTable;
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(12, 42, 268, 343);
		contentPane.add(scrollPane);
		scrollPane.setViewportView(productTable);

		productTable.addMouseListener(new MouseAdapter(){
			@Override
			public void mouseClicked(MouseEvent evt) {
				int row = productTable.rowAtPoint(evt.getPoint());
			    if (row >= 0) {
			    	idTextField.setText(productTable.getValueAt(row, 0).toString());
			    	nameTextField.setText((String) productTable.getValueAt(row, 1));
			    	priceTextField.setText(productTable.getValueAt(row, 2).toString());
			    	stockTextField.setText(productTable.getValueAt(row, 3).toString());
			    	comboBox.setSelectedIndex((Integer) productTable.getValueAt(row, 4)-1);
			    }
			}
		});
	}
	public JPanel getContentPane() {
		return contentPane;
	}

    public final JComboBox getComboBox() {
        return comboBox;
    }

    public final JTextField getNameTextField() {
        return nameTextField;
    }

    public final JTextField getPriceTextField() {
        return priceTextField;
    }

    public final JTextField getStockTextField() {
        return stockTextField;
    }

    public final JTextField getLowPriceTextLabel() {
        return lowPriceTextLabel;
    }

    public final JTextField getIdTextField() {
        return idTextField;
    }

	public final JRadioButton getAllProductRadioBtn() {
		return allProductRadioBtn;
	}

	public final JRadioButton getUnderStockRadioBtn() {
		return underStockRadioBtn;
	}

	public final JRadioButton getLowerPriceRadioBtn() {
		return lowerPriceRadioBtn;
	}
}
