package com.de.util;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public abstract class DBBaseUtil<T> {

	protected abstract List<T> parseRet(ResultSet resultSet) throws SQLException;

	protected T selectOne(String query) throws SQLException{
		List<T> list = select(query);
		if (list != null && list.size() > 0) {
			return list.get(0);
		}
		return null;
	}

	protected List<T> select(String query) throws SQLException {
		Connection con = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
			con = DBUtil.getConnection();
			preparedStatement = con.prepareStatement(query);
			resultSet = preparedStatement.executeQuery();
			return parseRet(resultSet);
		} finally {
			DBUtil.connClose(null,preparedStatement,con);
		}
	}

	protected void add(String sql) throws SQLException {
		executeUpdate(sql);
	}

	protected void update(String sql) throws SQLException {
		executeUpdate(sql);
	}

	protected void delete(String sql) throws SQLException {
		executeUpdate(sql);
	}

	private void executeUpdate(String sql) throws SQLException {
		Connection con = null;
		PreparedStatement preparedStatement = null;
		try {
			con = DBUtil.getConnection();
			preparedStatement = con.prepareStatement(sql);
			preparedStatement.executeUpdate();
		} finally {
			DBUtil.connClose(null,preparedStatement,con);
		}
	}


}