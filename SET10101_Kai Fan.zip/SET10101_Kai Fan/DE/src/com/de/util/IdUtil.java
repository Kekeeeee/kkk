package com.de.util;

import java.util.Random;

public class IdUtil {
	public static int getId() {
		int id = 0;
		String val = "";
		Random random = new Random();
		for (int i = 0; i < 8; i++) {
			val += String.valueOf(random.nextInt(10));
		}
		id = Integer.parseInt(val);
		return id;
	}
	
	public static void main(String[] args) {
		for (int i = 0; i < 50; i++) {
			System.out.println(getId());
		}
	}
}
