package com.de.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBUtil {
	
	private static String url; 
	private static String user; 
	private static String pwd;
	
	static{
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			
			url="jdbc:mysql://localhost:3306/dedb?characterEncoding=utf-8&useSSL=false";
			user="root";
			pwd="15003897990k";
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public static Connection getConnection(){
		
		Connection conn=null;
		try {
			conn=DriverManager.getConnection(url,user,pwd);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}
	
	public static void connClose(ResultSet resultSet,PreparedStatement preparedStatement,Connection connection){
		try {
			
			if (resultSet!=null) {
				resultSet.close();
			}
			
			if (preparedStatement!=null) {
				preparedStatement.close();
			}
			
			if (connection!=null) {
				connection.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		System.out.println(getConnection());
	}
}
