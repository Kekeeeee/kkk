package com.de.util;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * User:
 * Date: 2019-11-25
 * Time: 18:42
 */
public class StringUtil {

    public static boolean isBlank(String string) {
        return string == null || string.trim().length() == 0;
    }

    public static boolean isNotBlank(String string) {
        return !isBlank(string);
    }
}
