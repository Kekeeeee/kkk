package com.de.service;


public interface LoginService {
	public String login(String username, String password) throws Exception;
}
