package com.de.service;


import java.util.List;
import com.de.pojo.Category;

public interface CategoryService {
	public List<Category> getAllCategories() throws Exception;
}
