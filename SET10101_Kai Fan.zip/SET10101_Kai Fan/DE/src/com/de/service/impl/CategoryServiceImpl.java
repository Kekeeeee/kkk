package com.de.service.impl;


import java.util.List;

import com.de.dao.CategoryDao;
import com.de.dao.impl.CategoryDaoImpl;
import com.de.pojo.Category;
import com.de.service.CategoryService;

public class CategoryServiceImpl implements CategoryService {
	private CategoryDao categoryDao = new CategoryDaoImpl();
	public List<Category> getAllCategories() throws Exception {
		return categoryDao.getAllCategories();
	}

}
