package com.de.service.impl;

import com.de.dao.UserDao;
import com.de.dao.impl.UserDaoImpl;
import com.de.pojo.User;
import com.de.service.RegistService;
import com.de.util.IdUtil;

public class RegistServiceImpl implements RegistService {
	private UserDao userDao = new UserDaoImpl();
	
	@Override
	public boolean hasUser(String username) throws Exception {
		User user = userDao.hasUser(username);
		if (null == user)
			return false;
		return true;
	}
	
	@Override
	public String regist(String username, String password) throws Exception {
		User user = new User(IdUtil.getId(), username, password);
		userDao.addUser(user);
		return "regist success";
	}
}
