package com.de.service.impl;

import java.util.List;

import com.de.dao.ClientDao;
import com.de.dao.CountryDao;
import com.de.dao.OrderDao;
import com.de.dao.impl.ClientDaoImpl;
import com.de.dao.impl.CountryDaoImpl;
import com.de.dao.impl.OrderDaoImpl;
import com.de.pojo.Client;
import com.de.pojo.Country;
import com.de.service.ClientService;
import com.de.util.IdUtil;
import com.de.util.ServerUtil;

public class ClientServiceImpl implements ClientService {
	private ClientDao clientDao = new ClientDaoImpl();
	private OrderDao orderDao = new OrderDaoImpl();
	private CountryDao countryDao = new CountryDaoImpl();

	public boolean addClient(String name, String address, String email, String country) throws Exception {
		Country countryObj = countryDao.findCountryByName(country);
		Client client = new Client(IdUtil.getId(), name, address, email, countryObj.getId());
		if (!ServerUtil.validEmail(client.getEmail())) {
			return false;
		}
		clientDao.addClient(client);
		return true;
	}

	public boolean updateClient(int id, String name, String address, String email, String country) throws Exception {
		Country countryObj = countryDao.findCountryByName(country);
		Client client = new Client(id, name, address, email, countryObj.getId());
		if (!ServerUtil.validEmail(client.getEmail())) {
			return false;
		}
		clientDao.updateClient(client);
		return true;
	}

	public void deleteById(int id) throws Exception {
		clientDao.deleteClientById(id);
		orderDao.deleteOrderByClientId(id);
	}

	public List<Client> getAll() throws Exception {
		return clientDao.getAllClient();
	}

}
