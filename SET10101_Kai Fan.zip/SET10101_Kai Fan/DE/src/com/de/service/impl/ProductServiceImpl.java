package com.de.service.impl;

import java.util.List;

import com.de.dao.CategoryDao;
import com.de.dao.OrderDao;
import com.de.dao.ProductDao;
import com.de.dao.impl.CategoryDaoImpl;
import com.de.dao.impl.OrderDaoImpl;
import com.de.dao.impl.ProductDaoImpl;
import com.de.pojo.Category;
import com.de.pojo.Product;
import com.de.service.ProductService;
import com.de.util.IdUtil;

public class ProductServiceImpl implements ProductService{
	private ProductDao productDao = new ProductDaoImpl();
	private CategoryDao categoryDao = new CategoryDaoImpl();
	private OrderDao orderDao = new OrderDaoImpl();

	public String addProduct(String name, int price, int stock, String categoryName) throws Exception {
		categoryDao = new CategoryDaoImpl();
		String message = "";

		if (price <= 0) {
			message += "Invalid price, must be > 0;\n";
		}
		if (stock < 0) {
			message += "Invalid stock, must be >= 0;\n";
			return message;
		}

		Category category = categoryDao.findCategoryByName(categoryName);
		Product product = new Product(IdUtil.getId(), name, price, stock, category.getId());
		productDao.addProduct(product);
		return message;
	}

	public String updateProduct(int id, String name, int price, int stock, String categoryName) throws Exception {
		String message = "";
		if (price <= 0) {
			message += "Invalid price, must be > 0;\n";
		}
		if (stock < 0) {
			message += "Invalid stock, must be >= 0;\n";
			return message;
		}
		try {
			Category category = categoryDao.findCategoryByName(categoryName);
			Product product = new Product(id, name, price, stock, category.getId());
			productDao.updateProduct(product);
			return null;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}
	}

	public void deleteById(int id) throws Exception {
		productDao.deleteProductById(id);
		orderDao.deleteOrderByProductId(id);
	}

	public List<Product> getProductListUnderStock() throws Exception {
		return productDao.getProductListUnderStock();
	}

	public List<Product> getProductListUnderPrice(int price) throws Exception {
		return productDao.getProductListUnderPrice(price);
	}

	public List<Product> getAllProduct() throws Exception {
		return productDao.getAllProduct();
	}
}
