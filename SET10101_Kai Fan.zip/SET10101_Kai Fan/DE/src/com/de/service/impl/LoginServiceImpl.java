package com.de.service.impl;

import com.de.dao.UserDao;
import com.de.dao.impl.UserDaoImpl;
import com.de.pojo.User;
import com.de.service.LoginService;

public class LoginServiceImpl implements LoginService {
	private UserDao userDao = new UserDaoImpl();

	@Override
	public String login(String username, String password) throws Exception {
		User user = userDao.getUser(username, password);
		if (null == user) 
			return "username or password error.";
		return "login success";
	}

}
