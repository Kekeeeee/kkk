package com.de.service.impl;

import java.util.List;

import com.de.dao.CountryDao;
import com.de.dao.impl.CountryDaoImpl;
import com.de.pojo.Country;
import com.de.service.CountryService;

public class CountryServiceImpl implements CountryService {
	private CountryDao countryDao = new CountryDaoImpl();
	public List<Country> getAll() throws Exception {
		return countryDao.getAllCountry();
	}
}
