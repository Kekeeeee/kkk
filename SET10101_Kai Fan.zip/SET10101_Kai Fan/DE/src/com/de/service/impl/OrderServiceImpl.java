package com.de.service.impl;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.List;

import com.de.dao.ClientDao;
import com.de.dao.OrderDao;
import com.de.dao.ProductDao;
import com.de.dao.impl.ClientDaoImpl;
import com.de.dao.impl.OrderDaoImpl;
import com.de.dao.impl.ProductDaoImpl;
import com.de.pojo.Client;
import com.de.pojo.Order;
import com.de.pojo.Product;
import com.de.service.OrderService;
import com.de.util.IdUtil;

public class OrderServiceImpl implements OrderService {
	private OrderDao orderDao = new OrderDaoImpl();
	private ProductDao productDao = new ProductDaoImpl();
	private ClientDao clientDao = new ClientDaoImpl();

	public String insertNewOrder(int clientId, int productId, int quantity, boolean createBill) throws Exception {
		Order order = new Order(clientId, productId, quantity, IdUtil.getId());
		if (order.getQuantity() <= 0) {
			return "Invalid quantity, must be > 0";
		}
		Product product = productDao.getProductById(productId);
		if (product == null) {
			return "Product non exist";
		}
		if (product.getStock() < quantity) {
			return "Product under stock";
		}

		product.setStock(product.getStock() - quantity);
		productDao.updateProduct(product);
		orderDao.addOrder(order);
		if (createBill) {
			Client client = clientDao.getClientById(order.getClientId());
			Writer writer = null;
			try {
				String fileName = "Order " + orderDao.getLastOrder().getId() + " report.txt";
				String message = client.getName() + " ordered " + product.getName() + " quantity: " + order.getQuantity();
				writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileName), "utf-8"));
				writer.write(message);
				writer.close();
			} catch (IOException ignore) {
			}
		}
		return null;
	}
	
	public void deleteOrderByProductId(int productId) throws Exception {
		orderDao.deleteOrderByProductId(productId);
	}
	
	public void deleteOrderByClientId(int clientId) throws Exception{
		orderDao.deleteOrderByClientId(clientId);
	}
	
	public List<Order> getAllOrder() throws Exception {
		return orderDao.getAllOrder();
	}
}
