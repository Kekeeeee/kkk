package com.de.service;

import java.util.List;
import com.de.pojo.Product;

public interface ProductService {
	public String addProduct(String name, int price, int stock, String categoryName) throws Exception;
	public String updateProduct(int id, String name, int price, int stock, String categoryName) throws Exception;
	public void deleteById(int id) throws Exception;
	public List<Product> getProductListUnderStock() throws Exception;
	public List<Product> getProductListUnderPrice(int price) throws Exception;
	public List<Product> getAllProduct() throws Exception;
}
