package com.de.service;

import java.util.List;

import com.de.pojo.Order;

public interface OrderService {
	public String insertNewOrder(int clientId, int productId, int quantity, boolean createBill) throws Exception;
	public void deleteOrderByProductId(int productId) throws Exception;
	public void deleteOrderByClientId(int clientId) throws Exception;
	public List<Order> getAllOrder() throws Exception;
}
