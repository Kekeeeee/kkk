package com.de.service;

import java.util.List;

import com.de.pojo.Client;

public interface ClientService {
	public boolean addClient(String name, String address, String email, String country) throws Exception;
	public boolean updateClient(int id, String name, String address, String email, String country) throws Exception;
	public void deleteById(int id) throws Exception;
	public List<Client> getAll() throws Exception;
}
