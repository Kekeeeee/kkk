package com.de.service;


public interface RegistService {
	public boolean hasUser(String username) throws Exception;
	public String regist(String username, String password) throws Exception;
}
