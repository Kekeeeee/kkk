package com.de.service;

import java.util.List;
import com.de.pojo.Country;

public interface CountryService {
	public List<Country> getAll() throws Exception;
}
