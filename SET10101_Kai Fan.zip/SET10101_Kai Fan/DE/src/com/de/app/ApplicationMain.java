package com.de.app;

import java.awt.EventQueue;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.de.proc.ClientPageProcessor;
import com.de.proc.OrderPageProcessor;
import com.de.proc.ProductPageProcessor;
import com.de.view.ClientPageView;
import com.de.view.LoginView;
import com.de.view.OrderPageView;
import com.de.view.ProductPageView;

@SuppressWarnings("all")
public class ApplicationMain extends JFrame {
    private static final int WIDTH = 861;
    private static final int HEIGHT = 523;

	private JPanel contentPane;
	private JButton clientManagerBtn;
	private JButton productManangerBtn;
	private JButton orderManagerBtn;

	private JPanel clientJPanel;
	private JPanel orderJPanel;
	private JPanel productJPanel;

    public static void main(String[] args) {
    	EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                	LoginView frame = new LoginView();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

	/**
	 * Create the frame.
	 */
	public ApplicationMain() {
        setTitle("DE Store Manager System");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(200, 200, 900, 523);
        setLayout(null);

        // left menu
        initLeftMenu();

        // right: operation page
        initRightOperation();
	}

    private void initRightOperation() {
    	selectProductPage();
    }

    private void initLeftMenu() {
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null);

        contentPane.setBounds(20, 50, 180, 120);

        add(contentPane);

        productManangerBtn = new JButton("Manage Products");
        productManangerBtn.setBounds(12, 13, 143, 25);
        productManangerBtn.addActionListener((e) -> selectProductPage());
        contentPane.add(productManangerBtn);
        
        orderManagerBtn = new JButton("Add Order");
        orderManagerBtn.setBounds(12, 51, 143, 25);
        orderManagerBtn.addActionListener((e) -> selectOrderPage());
        contentPane.add(orderManagerBtn);
        
        clientManagerBtn = new JButton("Manage Clients");
        clientManagerBtn.setBounds(12, 89, 143, 25);
        clientManagerBtn.addActionListener((e) -> selectClientPage());
        contentPane.add(clientManagerBtn);
    }


    /**
     * show client page
     */
    public void selectClientPage() {
        if (clientJPanel == null) {
            ClientPageView clientView = new ClientPageView();
            clientJPanel = clientView.getContentPane();
            ClientPageProcessor clientPageProcessor = new ClientPageProcessor(clientView);
            clientJPanel.setBorder(BorderFactory.createEtchedBorder());
            clientJPanel.setBounds(200, 20, 650, 300);
        }
        clientJPanel.setVisible(true);

        if (orderJPanel != null) {
            orderJPanel.setVisible(false);
        }
        if (productJPanel != null) {
            productJPanel.setVisible(false);
        }
        add(clientJPanel);
    }

    /**
     * show product page
     */
    public void selectProductPage() {
        if (productJPanel == null) {
            ProductPageView productView = new ProductPageView();
            productJPanel = productView.getContentPane();
            ProductPageProcessor productPageProcessor = new ProductPageProcessor(productView);
            productJPanel.setBorder(BorderFactory.createEtchedBorder());
            productJPanel.setBounds(200, 20, 650, 450);
        }
        productJPanel.setVisible(true);

        if (clientJPanel != null) {
            clientJPanel.setVisible(false);
        }
        if (orderJPanel != null) {
            orderJPanel.setVisible(false);
        }
        add(productJPanel);
    }

    /**
     * show order page
     */
    public void selectOrderPage() {
        if (orderJPanel == null) {
            OrderPageView orderView = new OrderPageView();
            OrderPageProcessor orderPageProcessor = new OrderPageProcessor(orderView);
            orderJPanel = orderView.getContentPane();
            orderJPanel.setBorder(BorderFactory.createEtchedBorder());
            orderJPanel.setBounds(200, 20, 650, 320);
        }
        orderJPanel.setVisible(true);

        if (clientJPanel != null) {
            clientJPanel.setVisible(false);
        }
        if (productJPanel != null) {
            productJPanel.setVisible(false);
        }
        add(orderJPanel);
    }

}
