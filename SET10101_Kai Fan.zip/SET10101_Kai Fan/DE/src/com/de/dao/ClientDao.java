package com.de.dao;

import java.util.List;

import com.de.pojo.Client;

public interface ClientDao {
	public void addClient(Client client) throws Exception;
	public Client getClientById(int id) throws Exception;
	public List<Client> getAllClient() throws Exception;
	public void updateClient(Client client) throws Exception;
	public void deleteClientById(int id) throws Exception;
}
