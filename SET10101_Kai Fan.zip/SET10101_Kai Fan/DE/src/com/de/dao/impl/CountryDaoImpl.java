package com.de.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.de.dao.CountryDao;
import com.de.pojo.Country;
import com.de.util.DBBaseUtil;

public class CountryDaoImpl extends DBBaseUtil<Country> implements CountryDao {
	
	public Country findCountryByName(String name) throws SQLException{
		String query="select * from country where name=\'"+name+"\'";
		return selectOne(query);
	}


	public List<Country> getAllCountry() throws SQLException {
		String query = "select * from country";
		return select(query);
	}

	@Override
	protected  List<Country> parseRet(ResultSet resultSet) throws SQLException {
		List<Country> list = new ArrayList<Country>();
		while (resultSet.next()) {
			Country object = new Country();
			object.setId(resultSet.getInt("country_id"));
			object.setName(resultSet.getString("name"));
			list.add(object);
		}
		return list;
	}
}
