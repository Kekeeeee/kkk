package com.de.dao.impl;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.de.dao.OrderDao;
import com.de.pojo.Order;
import com.de.util.DBBaseUtil;

public class OrderDaoImpl extends DBBaseUtil<Order> implements OrderDao {

	public void addOrder(Order order) throws SQLException{
		StringBuffer stringBuffer = new StringBuffer("insert into product_order(product_order_id, client_id, product_id, quantity) values (");
		stringBuffer.append(order.getId()).append(",");
		stringBuffer.append(order.getClientId()).append(",");
		stringBuffer.append(order.getProductId()).append(",");
		stringBuffer.append(order.getQuantity()).append(")");
		add(stringBuffer.toString());
	}

	public Order getLastOrder() throws SQLException {
		String query = "Select * from product_order where product_order_id in (Select max(product_order_id) from product_order)";
		return selectOne(query);
	}

	public List<Order> getAllOrder() throws SQLException {
		String query = "select * from product_order";
		return select(query);
	}

	public void deleteOrderByProductId(int productId) throws SQLException{
		String deleteQuery="delete from product_order where product_id=" + productId;
		delete(deleteQuery);
	}
	
	public void deleteOrderByClientId(int clientId) throws SQLException {
		String deleteQuery = "delete from product_order where client_id=" + clientId;
		delete(deleteQuery);
	}
	

	@Override
	public List<Order> parseRet(ResultSet resultSet) throws SQLException {
		List<Order> list = new ArrayList<Order>();
		while (resultSet.next()) {
			Order object = new Order();
			object.setId(resultSet.getInt("product_order_id"));
			object.setProductId(resultSet.getInt("product_id"));
			object.setQuantity(resultSet.getInt("quantity"));
			object.setClientId(resultSet.getInt("client_id"));
			list.add(object);
		}
		return list;
	}
}
