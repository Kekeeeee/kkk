package com.de.dao.impl;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.de.dao.ClientDao;
import com.de.pojo.Client;
import com.de.util.DBBaseUtil;

public class ClientDaoImpl extends DBBaseUtil<Client> implements ClientDao {

	public void addClient(Client client) throws SQLException{
		StringBuffer stringBuffer = new StringBuffer("insert into client(client_id, name, address, email, country_id) values (");
		stringBuffer.append(client.getId()).append(",");
		stringBuffer.append("\'").append(client.getName()).append("\',");
		stringBuffer.append("\'").append(client.getAddress()).append("\',");
		stringBuffer.append("\'").append(client.getEmail()).append("\',");
		stringBuffer.append(client.getCountryId()).append(")");

		add(stringBuffer.toString());
	}

	public Client getClientById(int id) throws SQLException {
		String query = "Select * from client where id=" + id;
		return selectOne(query);
	}

	public List<Client> getAllClient() throws SQLException {
		String query = "select * from client";
		return select(query);
	}

	public void updateClient(Client client) throws SQLException{
		StringBuffer stringBuffer = new StringBuffer("update client set ");
		stringBuffer.append(" name = \'").append(client.getName()).append("\',");
		stringBuffer.append(" address = \'").append(client.getAddress()).append("\',");
		stringBuffer.append(" email = \'").append(client.getEmail()).append("\',");
		stringBuffer.append(" country_id = ").append(client.getCountryId());
		stringBuffer.append(" where client_id = ").append(client.getId());

		update(stringBuffer.toString());
	}

	public void deleteClientById(int id) throws SQLException {
		String deleteQuery = "delete from client where id=" + id;
		delete(deleteQuery);
	}

	@Override
	protected  List<Client> parseRet(ResultSet resultSet) throws SQLException {
		List<Client> list = new ArrayList<Client>();
		while (resultSet.next()) {
			Client object = new Client();
			object.setId(resultSet.getInt("client_id"));
			object.setName(resultSet.getString("name"));
			object.setAddress(resultSet.getString("address"));
			object.setEmail(resultSet.getString("email"));
			object.setCountryId(resultSet.getInt("country_id"));
			list.add(object);
		}
		return list;
	}
}
