package com.de.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.de.dao.CategoryDao;
import com.de.pojo.Category;
import com.de.util.DBBaseUtil;

public class CategoryDaoImpl extends DBBaseUtil<Category> implements CategoryDao {

	public Category findCategoryByName(String name) throws SQLException {
		String query = "select * from category where name=\'" + name + "\'";
		return selectOne(query);
	}

	public List<Category> getAllCategories() throws SQLException {
		String query = "select * from category";
		return select(query);
	}

	@Override
	protected List<Category> parseRet(ResultSet resultSet) throws SQLException {
		List<Category> list = new ArrayList<Category>();
		while (resultSet.next()) {
			Category category = new Category();
			category.setId(resultSet.getInt("category_id"));
			category.setName(resultSet.getString("name"));
			list.add(category);
		}
		return list;
	}
}
