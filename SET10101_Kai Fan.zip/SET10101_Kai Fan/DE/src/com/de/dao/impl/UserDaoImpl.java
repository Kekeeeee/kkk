package com.de.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.de.dao.UserDao;
import com.de.pojo.User;
import com.de.util.DBBaseUtil;

public class UserDaoImpl extends DBBaseUtil<User> implements UserDao {

	@Override
	public void addUser(User user) throws Exception {
		StringBuffer stringBuffer = new StringBuffer("insert into user(id, username, password) values (");
		stringBuffer.append(user.getId()).append(", '");
		stringBuffer.append(user.getUsername()).append("' , '");
		stringBuffer.append(user.getPassword()).append("')");
		add(stringBuffer.toString());
	}
	
	@Override
	public User getUser(String username, String password) throws Exception {
		String query = "Select * from user where username = '" + username + "' and password = '" + password + "'";
		return selectOne(query);
	}

	@Override
	protected List<User> parseRet(ResultSet resultSet) throws SQLException {
		List<User> list = new ArrayList<User>();
		while (resultSet.next()) {
			User object = new User();
			object.setId(resultSet.getInt("id"));
			object.setUsername(resultSet.getString("username"));
			object.setPassword(resultSet.getString("password"));
			list.add(object);
		}
		return list;
	}

	@Override
	public User hasUser(String username) throws Exception {
		String query = "Select * from user where username = '" + username + "'";
		return selectOne(query);
	}
}
