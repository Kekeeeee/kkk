package com.de.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.de.dao.ProductDao;
import com.de.pojo.Product;
import com.de.util.DBBaseUtil;

public class ProductDaoImpl extends DBBaseUtil<Product> implements ProductDao {
	private static final int U_STOCK = 3;

	public void addProduct(Product product) throws SQLException{
		StringBuffer stringBuffer = new StringBuffer("insert into product(product_id, name, price, stock, category_id) values (");
		stringBuffer.append(product.getId()).append(",");
		stringBuffer.append("\'").append(product.getName()).append("\',");
		stringBuffer.append(product.getPrice()).append(",");
		stringBuffer.append(product.getStock()).append(",");
		stringBuffer.append(product.getCategoryId()).append(")");

		add(stringBuffer.toString());
	}

	public Product getProductById(int id) throws SQLException {
		String query = "Select * from product where product_id =" + id;
		return selectOne(query);
	}

	public List<Product> getProductListUnderStock() throws SQLException {
		String query = "select * from product where stock <" + U_STOCK;
		return select(query);
	}


	public List<Product> getProductListUnderPrice(int price) throws SQLException {
		String query = "Select * from product where price <" + price;
		return select(query);
	}


	public List<Product> getAllProduct() throws SQLException {
		String query = "select * from product";
		return select(query);
	}

	public void updateProduct(Product product) throws SQLException{
		StringBuffer stringBuffer = new StringBuffer("update product set ");
		stringBuffer.append(" name = \'").append(product.getName()).append("\',");
		stringBuffer.append(" price = ").append(product.getPrice()).append(",");
		stringBuffer.append(" stock = ").append(product.getStock()).append(",");
		stringBuffer.append(" category_id = ").append(product.getCategoryId());
		stringBuffer.append(" where product_id = ").append(product.getId());

		update(stringBuffer.toString());
	}

	public void deleteProductById(int id) throws SQLException {
		String deleteQuery = "delete from product where product_id =" + id;
		delete(deleteQuery);
	}


	@Override
	protected List<Product> parseRet(ResultSet resultSet) throws SQLException {
		List<Product> list = new ArrayList<Product>();
		while (resultSet.next()) {
			Product object = new Product();
			object.setId(resultSet.getInt("product_id"));
			object.setStock(resultSet.getInt("stock"));
			object.setName(resultSet.getString("name"));
			object.setCategoryId(resultSet.getInt("category_id"));
			object.setPrice(resultSet.getInt("price"));
			list.add(object);
		}
		return list;
	}
}
