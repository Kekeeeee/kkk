package com.de.dao;
import java.util.List;

import com.de.pojo.Country;

public interface CountryDao {
	public Country findCountryByName(String name) throws Exception;
	public List<Country> getAllCountry() throws Exception;

}
