package com.de.dao;

import java.util.List;

import com.de.pojo.Order;

public interface OrderDao {
	public void addOrder(Order order) throws Exception;
	public Order getLastOrder() throws Exception;
	public List<Order> getAllOrder() throws Exception;
	public void deleteOrderByProductId(int productId) throws Exception;
	public void deleteOrderByClientId(int clientId) throws Exception;
}
