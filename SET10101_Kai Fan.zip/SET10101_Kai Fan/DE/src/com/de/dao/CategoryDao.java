package com.de.dao;

import java.util.List;
import com.de.pojo.Category;

public interface CategoryDao {
	public Category findCategoryByName(String name) throws Exception;
	public List<Category> getAllCategories() throws Exception;
}
