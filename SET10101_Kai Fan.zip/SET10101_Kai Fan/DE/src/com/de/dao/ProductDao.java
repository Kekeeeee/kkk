package com.de.dao;
import java.util.List;

import com.de.pojo.Product;

public interface ProductDao {
	public void addProduct(Product product) throws Exception;
	public Product getProductById(int id) throws Exception;
	public List<Product> getProductListUnderStock() throws Exception;
	public List<Product> getProductListUnderPrice(int price) throws Exception;
	public List<Product> getAllProduct() throws Exception;
	public void updateProduct(Product product) throws Exception;
	public void deleteProductById(int id) throws Exception;
}
