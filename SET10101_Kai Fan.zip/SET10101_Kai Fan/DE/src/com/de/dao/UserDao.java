package com.de.dao;

import com.de.pojo.User;

public interface UserDao {
	public void addUser(User user) throws Exception;
	public User getUser(String username, String password) throws Exception;
	public User hasUser(String username) throws Exception;
}
