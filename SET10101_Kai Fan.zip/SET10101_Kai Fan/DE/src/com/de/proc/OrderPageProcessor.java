package com.de.proc;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import com.de.pojo.Client;
import com.de.pojo.Order;
import com.de.pojo.Product;
import com.de.service.ClientService;
import com.de.service.OrderService;
import com.de.service.ProductService;
import com.de.service.impl.ClientServiceImpl;
import com.de.service.impl.OrderServiceImpl;
import com.de.service.impl.ProductServiceImpl;
import com.de.util.StringUtil;
import com.de.util.TableUtil;
import com.de.view.OrderPageView;

public class OrderPageProcessor {
	private OrderPageView orderControl;
	private OrderService orderService = new OrderServiceImpl();
	private ClientService clientService = new ClientServiceImpl();
	private ProductService productService = new ProductServiceImpl();

	/**
	 * Constructor for the OrderPageProcessor object
	 * @param view the view
	 */
	public OrderPageProcessor(OrderPageView view) {
		orderControl = view;
		try {
			List<Client> clients = clientService.getAll();
			if (null == clients || clients.size() == 0) {
				orderControl.showMessage("There is not have client.");
			} else {
				orderControl.setClientTable(TableUtil.createTable(clients));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			List<Product> products = productService.getAllProduct();
			if (null == products || products.size() == 0) {
				orderControl.showMessage("There is not have product.");
			} else {
				orderControl.setProductTabel(TableUtil.createTable(products));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		orderControl.addInsertActionListener(new CreateActionListener());
		orderControl.addShowActionListener(new ShowActionListener());
	}
	
	class CreateActionListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			try {
				int clientRow = orderControl.getClientTable().getSelectedRow();
				if (clientRow < 0) {
					orderControl.showMessage("Please select one client.");
					return;
				}
				int productRow = orderControl.getProductTabel().getSelectedRow();
				if (productRow < 0) {
					orderControl.showMessage("Please select one product.");
					return;
				}
				String quantity = orderControl.getTextField().getText();
				if (null == quantity || "".equals(quantity)) {
					orderControl.showMessage("Please input quantity.");
					return;
				}
				boolean createBill = orderControl.getBillCheckBox().isSelected();
				String msg= orderService.insertNewOrder(
						(Integer)orderControl.getClientTable().getValueAt(clientRow, 0), 
						(Integer)orderControl.getProductTabel().getValueAt(productRow, 0), 
						Integer.parseInt(quantity), 
						createBill);
				if(StringUtil.isNotBlank(msg)){
					orderControl.showMessage(msg);
				}
			} catch (Exception e1) {
				orderControl.showMessage("Could not insert, a database error ocurred!");
			}	
		}
	}
	
	class ShowActionListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			try {
				List<Order> orders = orderService.getAllOrder();
				if (null == orders || orders.size() == 0) {
					orderControl.showMessage("There is not have order.");
				} else {
					orderControl.showOrders(TableUtil.createTable(orders));
				}
			} catch (Exception e1) {
				orderControl.showMessage("Could not search, a database error ocurred!");
			}
		}
	}
}
