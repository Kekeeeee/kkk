package com.de.proc;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import com.de.pojo.Category;
import com.de.pojo.Product;
import com.de.service.CategoryService;
import com.de.service.ProductService;
import com.de.service.impl.CategoryServiceImpl;
import com.de.service.impl.ProductServiceImpl;
import com.de.util.StringUtil;
import com.de.util.TableUtil;
import com.de.view.ProductPageView;

public class ProductPageProcessor {
	private ProductPageView productPageView;

	private ProductService productService = new ProductServiceImpl();
	private CategoryService categoryService = new CategoryServiceImpl();
	
	/**
	 * Controller for the ProductPageProcessor object
	 *
	 * @param view the view
	 */
	@SuppressWarnings("unchecked")
	public ProductPageProcessor(ProductPageView view) {
		productPageView = view;
		try {
			List<Product> products = productService.getAllProduct();
			if (null == products || products.size() == 0) {
				productPageView.showMessage("There is not have product.");
			} else {
				productPageView.setProductTable(TableUtil.createTable(products));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			List<Category> categories = categoryService.getAllCategories();
			if (null == categories || categories.size() == 0) {
				productPageView.showMessage("There is not have category.");
			} else {
				for (Category category : categories) {
					productPageView.getComboBox().addItem(category.getName());
				}
			}
		} catch (Exception ignore) {
		}

		productPageView.addDeleteActionListener(new DeleteActionListener());
		productPageView.addSearchActionListener(new SearchActionListener());
		productPageView.addInsertActionListener(new InsertActionListener());
		productPageView.addUpdateActionListener(new UpdateActionListener());
	}

	public class DeleteActionListener implements ActionListener {
		public void actionPerformed(ActionEvent argo0) {
			try {
				productService.deleteById(productPageView.getIdOfSelected());
			} catch (Exception e) {
				productPageView.showMessage("Could not delete, a database error ocurred!");
			}
		}
	}

	class SearchActionListener implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			try {
				if (productPageView.getAllProductRadioBtn().isSelected()) {
					productPageView.setProductTable(TableUtil.createTable(productService.getAllProduct()));

				} else if (productPageView.getUnderStockRadioBtn().isSelected()) {
					productPageView.setProductTable(TableUtil.createTable(productService.getProductListUnderStock()));

				} else if (productPageView.getLowerPriceRadioBtn().isSelected()) {
					productPageView.setProductTable(TableUtil.createTable(productService.
							getProductListUnderPrice(Integer.parseInt(productPageView.getLowPriceTextLabel().getText()))));
				}
			} catch (Exception e) {
				productPageView.showMessage("Could not search, a database error ocurred!");
			}
		}
	}

	class InsertActionListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			try {
				String msg = productService.addProduct(productPageView.getNameTextField().getText(),
						Integer.parseInt(productPageView.getPriceTextField().getText()),
						Integer.parseInt(productPageView.getStockTextField().getText()),
						(String) productPageView.getComboBox().getSelectedItem());
				if (StringUtil.isNotBlank(msg)) {
					productPageView.showMessage(msg);
				}
			} catch (Exception e1) {
				productPageView.showMessage("Could not insert, a database error ocurred!");
			}
		}
	}

	class UpdateActionListener implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			try {
				String msg = productService.updateProduct(Integer.parseInt(productPageView.getIdTextField().getText()),
						productPageView.getNameTextField().getText(),
						Integer.parseInt(productPageView.getPriceTextField().getText()),
						Integer.parseInt(productPageView.getStockTextField().getText()),
						(String) productPageView.getComboBox().getSelectedItem());
				if (StringUtil.isNotBlank(msg)) {
					productPageView.showMessage(msg);
				}

			} catch (Exception e1) {
				e1.printStackTrace();
				productPageView.showMessage("Could not update, a database error ocurred!");
			}
		}
	}
}
