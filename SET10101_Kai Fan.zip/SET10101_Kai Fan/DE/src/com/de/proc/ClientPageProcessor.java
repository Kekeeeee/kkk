package com.de.proc;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import com.de.pojo.Client;
import com.de.pojo.Country;
import com.de.service.ClientService;
import com.de.service.CountryService;
import com.de.service.impl.ClientServiceImpl;
import com.de.service.impl.CountryServiceImpl;
import com.de.util.TableUtil;
import com.de.view.ClientPageView;

public class ClientPageProcessor {
	private ClientPageView clientPageView;

	private ClientService clientService = new ClientServiceImpl();
	private CountryService countryService = new CountryServiceImpl();

	/**
	 * Constructor for the ClientPageProcessor object
	 *
	 * @param view the view
	 */
	public ClientPageProcessor(ClientPageView view) {
		clientPageView = view;
		try {
			List<Client> clients = clientService.getAll();
			if (null == clients || clients.size() == 0) {
				clientPageView.showMessage("There is not have client.");
			} else {
				clientPageView.setTable(TableUtil.createTable(clients));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			for (Country country : countryService.getAll()) {
				clientPageView.getComboBox().addItem(country.getName());
			}
		} catch (Exception ignore) {
		}

		clientPageView.addDeleteActionListener(new DeleteActionListener());
		clientPageView.addSearchActionListener(new SearchActionListener());
		clientPageView.addInsertActionListener(new InsertActionListener());
		clientPageView.addUpdateActionListener(new UpdateActionListener());
	}

	class DeleteActionListener implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			try {
				clientService.deleteById(clientPageView.getIdOfSelected());
			} catch (Exception e) {
				clientPageView.showMessage("Could not delete, a database error ocurred!");
			}
		}
	}

	class SearchActionListener implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			try {
				List<Client> clients = clientService.getAll();
				if (null == clients || clients.size() == 0) {
					clientPageView.showMessage("There is not have client.");
				} else {
					clientPageView.setTable(TableUtil.createTable(clients));
				}
			} catch (Exception e) {
				clientPageView.showMessage("Could not search, a database error ocurred!");
			}
		}
	}

	class InsertActionListener implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			try {

				if (!clientService.addClient(clientPageView.getNameTextField().getText(),
						clientPageView.getAddressTestField().getText(),
						clientPageView.getEmailTextField().getText(),
						(String) clientPageView.getComboBox().getSelectedItem())) {
					clientPageView.showMessage("Invalid email address format!");
				}
			} catch (Exception e) {
				clientPageView.showMessage("Could not insert, a database error ocurred!");
			}
		}
	}

	class UpdateActionListener implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			try {
				if (!clientService.updateClient(Integer.parseInt(clientPageView.getCountryTextField().getText()),
						clientPageView.getNameTextField().getText(), clientPageView.getAddressTestField().getText(),
						clientPageView.getEmailTextField().getText(), (String) clientPageView.getComboBox().getSelectedItem())) {
					clientPageView.showMessage("Invalid email address format!");
				}
			} catch (Exception e) {
				clientPageView.showMessage("Could not update, a database error ocurred!");
			}
		}
	}
}
