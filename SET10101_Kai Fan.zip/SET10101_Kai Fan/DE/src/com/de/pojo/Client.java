package com.de.pojo;

public class Client {
	private int id;
	private String name;
	private String address;
	private String email;
	private int countryId;
	
	public Client(int id, String name, String address, String email, int countryId) {
		this.id = id;
		this.name = name;
		this.address=address;
		this.email=email;
		this.countryId = countryId;
	}
	
	public Client(){}

	@Override
	public String toString(){
		return id +", "+name+", "+ countryId;
	}

	public final String getAddress() {
		return address;
	}

	public final void setAddress(String address) {
		this.address = address;
	}

	public final String getEmail() {
		return email;
	}

	public final void setEmail(String email) {
		this.email = email;
	}

	public final int getId() {
		return id;
	}

	public final void setId(int id) {
		this.id = id;
	}

	public final String getName() {
		return name;
	}

	public final void setName(String name) {
		this.name = name;
	}

	public final int getCountryId() {
		return countryId;
	}

	public final void setCountryId(int countryId) {
		this.countryId = countryId;
	}
	

}
