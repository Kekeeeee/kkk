package com.de.pojo;

public class Order {
	private int id;
	private int clientId;
	private int productId;
	private int quantity;

	public Order(int clientId, int productId, int quantity, int id) {
		this.id = id;
		this.clientId = clientId;
		this.productId = productId;
		this.quantity = quantity;
	}

	public Order() {
	}

	public final int getId() {
		return id;
	}

	public final void setId(int id) {
		this.id = id;
	}

	public final int getClientId() {
		return clientId;
	}

	public final void setClientId(int clientId) {
		this.clientId = clientId;
	}

	public final int getProductId() {
		return productId;
	}

	public final void setProductId(int productId) {
		this.productId = productId;
	}

	public final int getQuantity() {
		return quantity;
	}

	public final void setQuantity(int quantity) {
		this.quantity = quantity;
	}

}
