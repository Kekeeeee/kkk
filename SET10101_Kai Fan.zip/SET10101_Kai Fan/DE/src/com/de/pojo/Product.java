package com.de.pojo;

public class Product {
	private int id;
	private String name;
	private int price;
	private int stock;
	private int categoryId;
	
	public Product(int id, String name, int price, int stock, int categoryId) {
		this.id = id;
		this.name = name;
		this.price = price;
		this.stock = stock;
		this.categoryId = categoryId;
	}
	
	public Product(){}

	public final int getId() {
		return id;
	}

	public final void setId(int id) {
		this.id = id;
	}

	public final String getName() {
		return name;
	}

	public final void setName(String name) {
		this.name = name;
	}

	public final int getPrice() {
		return price;
	}

	public final void setPrice(int price) {
		this.price = price;
	}

	public final int getStock() {
		return stock;
	}

	public final void setStock(int stock) {
		this.stock = stock;
	}

	public final int getCategoryId() {
		return categoryId;
	}

	public final void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	
}
