/**
 * Spring Security configuration.
 */
package uk.ac.napier.soc.ssd.coursework.security;
