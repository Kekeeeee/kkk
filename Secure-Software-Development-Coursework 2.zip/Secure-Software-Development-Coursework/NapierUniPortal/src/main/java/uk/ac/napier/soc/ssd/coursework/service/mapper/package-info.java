/**
 * MapStruct mappers for mapping domain objects and Data Transfer Objects.
 */
package uk.ac.napier.soc.ssd.coursework.service.mapper;
