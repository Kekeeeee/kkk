/**
 * Spring Data Elasticsearch repositories.
 */
package uk.ac.napier.soc.ssd.coursework.repository.search;
