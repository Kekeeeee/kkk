/**
 * View Models used by Spring MVC REST controllers.
 */
package uk.ac.napier.soc.ssd.coursework.web.rest.vm;
