package uk.ac.napier.soc.ssd.coursework.appsensor;

import com.google.gson.Gson;
import org.owasp.appsensor.core.*;
import org.owasp.appsensor.core.geolocation.GeoLocation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetails;

import java.security.GeneralSecurityException;
import java.util.Random;

public class EventEmitter {
    Authentication auth = SecurityContextHolder.getContext().getAuthentication();
    private User user = new User(
        ((UserDetails)auth.getPrincipal()).getUsername(),
        new IPAddress(((WebAuthenticationDetails)auth.getDetails()).getRemoteAddress(),
        new GeoLocation(37.596758, -121.647992))
    );
    private DetectionSystem detectionSystem = new DetectionSystem("myclientapp");
    private Gson gson = new Gson();

    private DetectionPoint detectionPoint;

    public EventEmitter(DetectionPoint detectionPoint) {
        this.detectionPoint = detectionPoint;
    }

    public ResponseEntity<String> send() {
        System.err.format("Sending event type '%s' from user '%s' and system '%s'%s", detectionPoint.getLabel(), user.getUsername(), detectionSystem.getDetectionSystemId(), System.getProperty("line.separator"));
        Event event = new Event(user, detectionPoint, detectionSystem);
        System.err.println("sending || " + gson.toJson(event) + " ||");

        ResponseEntity<String> responseEntity = null;

        try {
            responseEntity = HttpClient.send(user, detectionPoint, detectionSystem);
        } catch (GeneralSecurityException e) {
            e.printStackTrace();
        }
        return responseEntity;
    }


}
