/**
 * Audit specific code.
 */
package uk.ac.napier.soc.ssd.coursework.config.audit;
