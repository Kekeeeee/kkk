/**
 * JPA domain objects.
 */
package uk.ac.napier.soc.ssd.coursework.domain;
