/**
 * Service layer beans.
 */
package uk.ac.napier.soc.ssd.coursework.service;
