package uk.ac.napier.soc.ssd.coursework.domain.enumeration;

/**
 * The EntryLevel enumeration.
 */
public enum EntryLevel {
    BEGINNER, INTERMEDIATE, EXPERT
}
