/**
 * Credit to Dominik Schadow. The code used in this application has been adapted from https://github.com/dschadow/Java-Web-Security.
 */
package uk.ac.napier.soc.ssd.sql.servlets;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import static uk.ac.napier.soc.ssd.sql.servlets.CustomerTable.writeCustomers;
import static uk.ac.napier.soc.ssd.sql.servlets.HibernateUtil.getSessionFactory;

@WebServlet(name = "HQLServlet", urlPatterns = {"/HQLServlet"})
public class HQLServlet extends HttpServlet {
    private static final Logger LOGGER = LoggerFactory.getLogger(HQLServlet.class);

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException {
        String name = request.getParameter("name");
        LOGGER.info("Received {} as POST parameter", name);

        try (Session session = getSessionFactory().openSession()) {
            Query query = session.createQuery("");

            writeCustomers(response, name, query.list());
        } catch (HibernateException ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
    }
}
