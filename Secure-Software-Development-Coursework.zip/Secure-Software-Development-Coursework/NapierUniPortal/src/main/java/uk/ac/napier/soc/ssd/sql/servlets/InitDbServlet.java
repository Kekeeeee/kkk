/**
 * Credit to Dominik Schadow. The code used in this application has been adapted from https://github.com/dschadow/Java-Web-Security.
 */
package uk.ac.napier.soc.ssd.sql.servlets;

import static uk.ac.napier.soc.ssd.sql.servlets.HibernateUtil.getSessionFactory;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

import org.hibernate.Session;

@WebServlet(name = "InitDbServlet", urlPatterns = {"/"})
public class InitDbServlet extends HttpServlet {
    public void init() {
        Session session = getSessionFactory().openSession();
        session.close();
    }
}
