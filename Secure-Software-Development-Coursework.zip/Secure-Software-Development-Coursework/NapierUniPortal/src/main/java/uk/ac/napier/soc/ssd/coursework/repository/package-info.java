/**
 * Spring Data JPA repositories.
 */
package uk.ac.napier.soc.ssd.coursework.repository;
