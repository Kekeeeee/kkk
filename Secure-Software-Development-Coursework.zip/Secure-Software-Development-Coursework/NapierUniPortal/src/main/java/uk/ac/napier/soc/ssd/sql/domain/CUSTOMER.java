/**
 * Credit to Dominik Schadow. The code used in this application has been adapted from https://github.com/dschadow/Java-Web-Security.
 */
package uk.ac.napier.soc.ssd.sql.domain;

import javax.persistence.*;

@Entity
@Table(name="CUSTOMER")
public class CUSTOMER {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "CUST_ID")
    private int CUST_ID;
    private String name;
    private String status;
    @Column(name = "order_limit")
    private int orderLimit;
    private String hint;

    public int getCustId() {
        return CUST_ID;
    }

    public void setCustId(int custId) {
        this.CUST_ID = custId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getOrderLimit() {
        return orderLimit;
    }

    public void setOrderLimit(int orderLimit) {
        this.orderLimit = orderLimit;
    }

    public String getHint() {
        return hint;
    }

    public void setHint(String hint) {
        this.hint = hint;
    }

    @Override
    public String toString() {
        StringBuilder customer = new StringBuilder();
        customer.append("ID ").append(CUST_ID);
        customer.append(", Name ").append(name);
        customer.append(", Status ").append(status);
        customer.append(", Order Limit ").append(orderLimit);
        customer.append(", Hint ").append(hint);

        return customer.toString();
    }
}
